# Step 8 Final Balanced Passage Selection Report

## Status

Complete.

## Input

Step 8 used the canonical Gutenberg candidate pool generated in Step 7.

## Selection rule

The selection is deterministic. For each of 12 works, the pool was filtered to candidates that:

- passed Step 7 length/sentence checks,
- had 450–650 words,
- had at least 5 sentences,
- were not from the first five candidate windows of the work,
- did not contain front-matter or boilerplate indicators such as Project Gutenberg markers, contents pages, illustration blocks, or preface material.

From each work, 30 candidates were selected by evenly spacing across the remaining candidate sequence.

## Final dataset size

- authors: 6
- works: 12
- selected passages per work: 30
- selected passages per author: 60
- total selected original passages: 360

## Counts by author

- austen: 60 passages, mean words 565.53
- dickens: 60 passages, mean words 564.62
- poe: 60 passages, mean words 566.28
- shelley: 60 passages, mean words 567.32
- twain: 60 passages, mean words 561.47
- wilde: 60 passages, mean words 566.53

## Completion judgment

Step 8 is complete for the original-passage layer. The selected original passages are ready for the later rewriting conditions: paraphrase, modernize, and simplify.
